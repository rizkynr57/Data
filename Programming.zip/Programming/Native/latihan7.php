<html>
  <head></head>
  <body>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama Mahasiswa</td>
          <td>:</td>
          <td><input type="text" name="nama"></td>
        </tr>
        <tr>
          <td>NIM</td>
          <td>:</td>
          <td><input type="number" name="nim"></td>
        </tr>
        <tr>
          <td>Nilai</td>
          <td>:</td>
      <td><input type="number" name="nikai" min="0" max"100"></td>
        </tr>
        <tr>
          <td>Nama Dosen</td>
          <td>:</td>
          <td><input type="name" name="dosen"></td>
        </tr>
        <tr>
          <td>Mata Kuliah</td>
          <td>:</td>
          <td>
            <select name="matkul" required>
              <option value="">Pilih</option>
              <option value="Bahasa Indonesia">Bahasa Indonesia</option>
              <option value="Bahasa Inggris">Bahasa Inggris</option>
              <option value="Matematika">Matematika</option>
            </select>
          </td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="save" value="Save"></td>
        </tr>
      </table>
    </form>
  </body>
</html>



<?php    
    if (isset($_POST['save'])) {
      $nama = $_POST['nama'];
      $nim = $_POST['nim'];
      $nilai = $_POST['nilai'];
      $dosen = $_POST['dosen'];
      $matkul = $_POST['matkul'];
    
    
    class mahasiswa
    {
        public $nama;
        public $nim;
        public $dosen;
        
        public function __construct($nama,$nim,$dosen)
        {
            $this->nama = $nama;
            $this->nim = $nim;
            $this->dosen = $dosen;
        }
        public function mahasiswa($nama,$nim,$dosen)
        {
            $data = "Nama : ".$nama."<br>";
            $data .= "NIM : ".$nim."<br>";
            $data .= "Dosen : ".$dosen."<br>";
            return $data;
        }
    }
    class matakuliah extends mahasiswa 
    {
        public $matkul;
        public $nilai;
        
        public function __construct($matkul,$nilai)
        {
            $this->matkul = $matkul;
            $this->nilai = $nilai;
        }
        public function biodata($nama,$nim,$dosen)
        {
            return $this->mahasiswa($nama,$nim,$dosen);
        }
        public function matkulnilai($matkul,$nilai)
        {
            $data2 = "Nilai : ".$nilai."<br>";
            $data2 .= "Mata Kuliah : ".$matkul."<br>";
            return $data2;
        }
        public function nilai($nilai)
        {
            if ($nilai >= 85) {
                $ket = "Grade A";
            } else if ($nilai >= 75) {
                $ket = "Grade B";
            } else if ($nilai >= 65) {
                $ket = "Grade C";
            } else {
                $ket = "Grade D";
            }
            return $ket;
        }
    }
    
$kuliah = new matakuliah($nama,$nim,$nilai,$dosen,$matkul);
echo $kuliah->biodata($nama,$nim,$dosen);
echo $kuliah->matkulnilai($matkul,$nilai);
echo "Status : ".$kuliah->nilai($nilai);
}
?>