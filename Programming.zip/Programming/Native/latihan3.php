<html>
  <head></head>
  <body>
    <form action="" method="POST">
      Masukan jumlah bintang : <input type="number" name="nom">
      <input type="submit" name="hitung" value"Menghitung">
      
    </form>
  </body>
</html>

<?php
     if (isset($_POST['hitung'])) {
       $angka = $_POST['nom'];
       if ($angka <= 5) {
           for ($i = 0; $i <= 5; $i++) {
           for ($j = 5; $j >= $i; $j--) {
             echo "&nbsp";
           }
           for ($k = 0; $k <= $i; $k++) {
           echo " * ";
         }
         echo "<br>";
       }
       
          for ($a = 0; $a <= 5; $a++) {
            for ($b = 0; $b <= $a; $b++) {
              echo "&nbsp";
            }
            for ($c = 5; $c >= $a; $c--) {
              echo " * ";
            }
            echo "<br>";
          }
        } else {
          echo "Tidak Ada";
        }
     }
 ?>