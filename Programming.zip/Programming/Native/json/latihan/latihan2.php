<?php
$dataJson = '{
    "Title": "The Graduate",
    "Year": "1967",
    "Rated": "Approved",
    "Released": "22 Dec 1967",
    "Runtime": "106 min",
    "Genre": [
      "Comedy",
      "Drama",
      "Romance"
    ],
    "Director": "Mike Nichols",
    "Writers": [
      "Calder Willingham (screenplay)",
      "Buck Henry (screenplay)",
      "Charles Webb (based on the novel by)"
    ],
    "Actors": [
      "Anne Bancroft",
      "Dustin Hoffman",
      "Katharine Ross",
      "William Daniels"
    ],
    "Plot": "Ben has recently graduated college, with his parents now expecting great things from him. At his \"Homecoming\" party, Mrs. Robinson, the wife of his fathers business partner, has Ben drive her home, which leads to an affair between the two. The affair eventually ends, but comes back to haunt him when he finds himself falling for Elaine, Mrs. Robinsons daughter.",
    "Language": "English",
    "Country": "USA",
    "Awards": "Won 1 Oscar. Another 22 wins & 13 nominations.",
    "Poster":"http://ia.media-imdb.com/images/M/MV5BMTQ0ODc4MDk4NI5BMI5BanBNXkFtZTcwMTEzNzgzNA@@._V1_SX300.jpg",
    "imdbRating": "8.1",
    "imdbVotes": "183,131",
    "imdbID": "tt0061722"
  }';
?>
    <html>
        <head></head>
        <body>
        <?php $data = json_decode($dataJson);?>
        <center><?php echo $data->Title . "<br>";?></center>
        <center><img src="icon.jpg"><br></center>
        <?php echo"<p>". $data->Plot ."</p>"."<br>"?>
        <?php echo "<b>Tahun Rilis : </b>".$data->Year ."<br>"?>
        <?php echo "<b>Tanggal Rilis : </b>".$data->Released ."<br>"?>
        <?php echo "<b>Durasi Film : </b>".$data->Runtime ."<br>"?>
        <?php echo "<b>Genre : </b>". implode(",",$data->Genre) ."<br>"?>
        <?php echo "<b>Director : </b>".$data->Director. "<br>"?>
        <?php echo "<b>Penulis : <li></b>". implode("<li>",$data->Writers). "<br>"?>
        <?php echo "<b>Pemeran : <li></b>". implode("<li>",$data->Actors). "<br>"?>
        <?php echo "<b>Bahasa : </b>".$data->Language. "<br>"?>
        <?php echo "<b>Negara : </b>".$data->Country. "<br>"?>
        <?php echo "<b>Penghargaan : </b>".$data->Awards. "<br>"?>
        <?php echo "<b>Nilai : </b>".$data->imdbRating. "<br>"?>
        <?php echo "<b>Vote : </b>".$data->imdbVotes." Orang". "<br>"?>
        <?php echo "<b>ImdbID : </b>".$data->imdbID. "<br>"?>
        </body>
    </html>