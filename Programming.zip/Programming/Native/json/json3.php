<?php 
    $data = [
        "nama" => "Ujang",
        "domisili" => "Bandung"
    ];

    echo json_encode($data);

?>