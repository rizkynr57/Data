<?php 
    function tampilAngka($jumlah, $index = 1){
        echo "Perulangan ke-$index <br>";

        if($index < $jumlah) {
            tampilAngka($jumlah, $index + 1);
        } 
    }
    echo tampilAngka(20);
?>