<?php 
    $user = "achmatim";
    $pass = "123";
    if ($user == "achmatim" && $pass = "123") {
        echo "Login Berhasil";
    } else {
        echo "Login Gagal";
    }
?>