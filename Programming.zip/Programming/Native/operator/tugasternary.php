<?php
    $nilaiAkademik = 87;
    $nilaiAtletik = 83;
    echo "Nilai Akademik : $nilaiAkademik<br>";
    echo "Nilai Atletik : $nilaiAtletik<br>";
    $lulus = $nilaiAkademik >= 85 && $nilaiAtletik >= 83;
    $jawab = $lulus ? " Lulus": " Tidak lulus";
    echo "dinyatakan : ".$jawab;
    echo "<br>";
?>