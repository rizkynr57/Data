<?php 
    $sim = "ya";
    $stnk = "ya";

    if($sim == "ya") {
        if($stnk == "ya") {
            echo "Selamat menjalankan aktifitas, Hati - hati berkendara";
        } else {
            echo "Maaf anda kami tilang";
            }
        } else {
            echo "Maaf anda kami tilang";
    }
?>