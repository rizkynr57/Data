<?php 
echo "No. 1<br>";
    $i = 2;
    do {
        echo "$i ";
        $i*=2;
    } while ($i <= 64);

echo "<hr>";
echo "No. 2<br>";
    $j = 625;
    do {
        echo "$j ";
        $j/=5;
    } while ($j >= 5);
echo "<hr>";
echo "No. 3<br>";
    $bill = [18, 45, 29, 61, 47, 34];
    for ($m = 0; $m < count($bill); $m++) {
        $result[$m] = $bill[$m] % 3;
        echo "$bill[$m] % 3 = $result[$m]<br>";
    }

echo "<hr>";


echo "No. 4<br>";
    for($a = 1; $a <= 6; $a++) {
        for($b = 6; $b >= $a; $b--) {
            echo " ";
        }
        for($c = 2; $c <= $a; $c++) {
            echo " * ";
        }
        echo "<br>";
    }
echo "<hr>";
echo "No. 5<br>";
    for($e = 0; $e < 5; $e++) {
        for($f = 5; $f > $e; $f--) {
            echo "&nbsp";
        }
        for($g = 0; $g <= $e; $g++) {
            echo " *";
        }
            echo "<br>";
    }

    for($z = 0; $z < 5; $z++) {
        for($x = 5; $x > $z; $x--) {
            echo "&nbsp";
        }
        for($v = 0; $v <= $z; $v-=1) {
            echo " *";
        }
            echo "<br>";
    }
    
?>