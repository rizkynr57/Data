<?php 
    $jumlah = 10;
    $beroperasi = 6;
    for ($noKereta = 1; $noKereta <= $jumlah; $noKereta++) {
        if($noKereta <= 6 && $noKereta !== 5 )  {
            echo "Kereta Nomer : ".$noKereta." Beroperasi dengan baik<br>";
        }
        else if($noKereta == 8 || $noKereta == 10 || $noKereta == 5) {
            echo "Kereta Nomer : ".$noKereta." Sedang Lembur<br>";
        }
        else {
            echo "Kereta Nomer : ".$noKereta." Sedang Tidak Beroperasi<br>";
        }
    }

?>