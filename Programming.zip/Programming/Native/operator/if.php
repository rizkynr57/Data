<?php 
    $nilai = 75;
    if ($nilai >= 75) {
        echo "Nilai anda : $nilai, Anda Lulus";
    }
?>