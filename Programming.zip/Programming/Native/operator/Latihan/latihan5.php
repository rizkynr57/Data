<html>
    <head></head>
    <body>
    <form action = "latihan5.2.php" method ="POST">
        <table>
        <center><h3>Program Peminjaman Mobil</h3></center>
    <tr>
        <td>Nama</td> 
        <td>:</td>
        <td><input type="text" name="nama" required><br></td>
    </tr>   
    <tr>
        <td>NIK</td> 
        <td>:</td>
        <td><input type="number" name="nik" required><br></td>
    </tr>   
    <tr>
        <td>Jenis Kelamin</td>
        <td>:</td>
        <td><input type="radio" name="jk" value = "Laki - Laki">Laki-Laki
            <input type="radio" name="jk" value = "Perempuan">Perempuan
        <br></td>
    </tr>

    <tr>
        <td>Agama</td>
        <td>:</td>
        <td><select name ="agama" value="agama" required>
            <option value="">Pilih :</option>
            <option value= "Islam">Islam</option>
            <option value= "Kristen">Kristen</option>
            <option value= "Hindu">Hindu</option>
            <option value= "Buddha">Buddha</option>
        </select>
        </td>
    </tr>
    <tr>
            <td>Nama Mobil</td>
            <td>:</td>
            <td><input type = "text" name="mobil" required></td>
    </tr>
    <tr>
            <td>Jenis Mobil</td>
            <td>:</td>
            <td><select name="jenis" value="jenis" required> 
                <option value ="">Pilih Jenis</option>
                <option value ="SUV">SUV</option> 
                <option value ="Convertible">Convertible</option> 
                <option value ="Coupe">Coupe</option> 
                <option value ="Hatchback">Hatchback</option> 
        </select>   <td>
    </tr>
    
    <tr>
            <td>Merk Mobil</td>
            <td>:</td>
            <td><select name="merk" value="merk" required> 
                <option value ="">Pilih Merk</option>
                <option value ="Toyota">Toyota</option> 
                <option value ="Daihatsu">Daihatsu</option> 
                <option value ="Honda">Honda</option> 
                <option value ="Misubishi">Mitsubishi</option> 
        </select>   </td>
    </tr>
    <tr>
        <td>No. Plat Mobil</td>
        <td>:</td>
        <td><input type= "text" name="plat"></td>
    </tr>
    <tr>
        <td>Tanggal Peminjaman</td>
        <td>:</td>
        <td><input type = "date" name="tglpinjam" required></td>
    </tr>
    <tr>
        <td>Tanggal Kembali</td>
        <td>:</td>
        <td><input type = "date" name="tglkembali" required></td>
    </tr>
    <tr>
        <td>Penjamin</td>
        <td>:</td>
        <td><select name="penjamin" value="penjamin" required> 
                <option value ="">Pilih :</option>
                <option value ="FC ">FC</option> 
                <option value ="KTP">KTP</option> 
                <option value ="SIM">SIM</option> 
                <option value ="FC KK">FC KK</option> 
        </select>   <td>
    </tr>
    <tr>
        <td>Ingin Memakai Supir ? </td>
        <td>:</td>
        <td><select name="supir" value = "supir">
            <option value="">Pilih : </option>
            <option value="Iya">Iya</option>
            <option value="Tidak">Tidak</option>
        </select>
        </td>
    </tr>
    <tr>
    <td></td>
    <td></td>
       <td><input type="submit" name="input" value="Simpan"></td>
    </tr>
    </form>
</table>
    </body>
</html>