<html>
    <head></head>

    <body>

    <form action = "" method="POST">
        <h1>Halaman Persegi Panjang</h1>
    <table>
        <tr>
    <td>Masukan Panjang : </td> 
    <td>:</td> 
    <td><input type="number" name= "panjang" required></td>
</tr>   
<tr>
    <td>Masukan Lebar : </td> 
    <td>:</td> 
    <td><input type="number" name= "lebar" required></td>
</tr>
</table>
<input type = "submit" name ="hasil" value="Hasil">

    </form>
    </body>
</html>

<?php 
    if(isset($_POST['hasil'])) {
        $panjang = @$_POST['panjang'];
        $lebar = @$_POST['lebar'];

        $luas = $panjang * $lebar;
        $keliling = ($panjang + $lebar) * 2;
        echo "Luas Segigita : $luas<br>";
        echo "Keliling Segitiga : $keliling<br>";
    }

?>

<a href = "latihan2.php">Back</a>