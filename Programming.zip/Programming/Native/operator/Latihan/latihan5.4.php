<?php 
        if(isset($_POST['input'])) {
            $bayar = $_POST['bayar'];
            $total = $_POST['total'];

            if ($bayar >= $total) {
                $ket =  "Terima Kasih";
            } else
                $ket = "Uang Anda Kurang, Anda Kami Blacklist";

            echo "Keterangan : $ket<br>";
            $kem = $bayar - $total;
            echo "Kembalian Anda : $kem";
        }
?>