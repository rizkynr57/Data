<?php
    if (isset($_POST['input'])) {
        $nama = $_POST['nama'];
        $nik = $_POST['nik'];
        $jk = $_POST['jk'];
        $agama = $_POST['agama'];
        $tglpinjam = $_POST['tglpinjam'];
        $tglkembali = $_POST['tglkembali'];
        $penjamin = $_POST['penjamin'];
        $mobil = $_POST['mobil'];
        $plat = $_POST['plat'];
        $jenis = $_POST['jenis'];
        $merk = $_POST['merk'];
        $supir = $_POST['supir'];
        $tglverifikasi = $_POST['tglverifikasi'];
        
        echo "Nama : $nama<br>";
        echo "NIK : $nik<br>";
        echo "Jenis Kelamin : $jk<br>";
        echo "Agama : $agama<br>";
        echo "Tanggal Peminjaman : $tglpinjam<br>";
        echo "Tanggal Kembali : $tglkembali<br>";
        echo "Penjamin : $penjamin<br>";
        echo "Nama mobil : $mobil<br>";
        echo "No. Plat Mobil : $plat<br>";
        echo "Jenis Mobil : $jenis<br>";
        echo "Merk Mobil : $merk<br>";
        echo "Supir : $supir<br>";
        echo "<hr>";
        $denda=240000;

        $hari = (strtotime($tglkembali) - strtotime($tglpinjam)) / 60 / 60 / 24;
        echo "Lama Pinjaman : $hari Hari<br>";
        if ($supir == "Iya") {
           $biaya = 275000;
       } else {
           $biaya = 100000;
       }
       echo "Biaya Harian : Rp$biaya<br>";

       $telat = (strtotime($tglverifikasi) - strtotime($tglkembali)) / 60 / 60 / 24;
       
       echo "Telat Mengembalikan : $telat Hari<br>";

       $totaldenda = $denda * $telat;
       echo "Denda : Rp$totaldenda<br>";

        $subtotal = $hari * $biaya;
        echo "Total Biaya : Rp$subtotal<br>";
        $subtotal2 = $telat * $denda;
        echo "Total Denda : Rp$subtotal2<br>";
        
        $total = $subtotal + $subtotal2;
        echo "Total Pembayaran : Rp$total<br>";

    }
?>
<html>
    <head>
        <body>
        <form  action ="latihan5.4.php" method="POST">
            <table>
                <tr>
                    <input type="hidden" name="total" value = <?php echo "$total";?>>
                    <td>Pembayaran</td>
                    <td>:</td>
                    <td><input type="number" name="bayar" required>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type ="submit" name="input" value="Bayar"></td>
                </tr>
            </table>
        </body>
    </head>
</html>