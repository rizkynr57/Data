<html>
    <head></head>
    <body>
    <form action = "" method="POST">
    <table>
        <tr>
    <td>Pilih Program Bangun Ruang</td> 
    <td>:</td> 
    <td><select name = "pilihan" value="bidang" required>
        <option value=""></option>
            <option value= "1">Luas & keliling persegi</option>
            <option value= "2">Luas & keliling lingkaran</option>
            <option value= "3">Luas & keliling segitiga</option>
            <option value= "4">Luas & keliling persegi panjang</option>
    </select>
</td>
</tr>   
</table>
<input type = "submit" name ="pilih" value="Pilih">
    </form>
    </body>
</html>
<?php 
if (isset($_POST['pilih'])) {
    $pilih = $_POST['pilihan'];
    if($pilih == 1) {
        header("location:persegi.php");
    } else if ($pilih == 2) {
        header("location:lingkaran.php");
    } else if ($pilih == 3) {
        header("location:segitiga.php");
    } else if ($pilih == 4) {
        header("location:persegipanjang.php");
    }
    
}
?>