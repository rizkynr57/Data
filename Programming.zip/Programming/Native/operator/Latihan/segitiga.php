<html>
    <head></head>

    <body>

    <form action = "" method="POST">
        <h1>Halaman Segitiga</h1>
    <table>
        <tr>
    <td>Masukan Alas : </td> 
    <td>:</td> 
    <td><input type="number" name= "alas" required></td>
</tr>   
<tr>
    <td>Masukan Tinggi : </td> 
    <td>:</td> 
    <td><input type="number" name= "tinggi" required></td>
</tr>
<tr>
    <td>Masukan Panjang Sisi : </td> 
    <td>:</td> 
    <td><input type="number" name= "pangsi" required></td>
</tr>

</table>
<input type = "submit" name ="hasil" value="Hasil">

    </form>
    </body>
</html>

<?php 
    if(isset($_POST['hasil'])) {
        $alas = @$_POST['alas'];
        $tinggi = @$_POST['tinggi'];
        $pangsi = @$_POST['pangsi'];

        $luas = ($alas * $tinggi) *1/2;
        $keliling = $pangsi + $pangsi + $pangsi;
        echo "Luas Segigita : $luas<br>";
        echo "Keliling Segitiga : $keliling<br>";
    }

?>

<a href = "latihan2.php">Back</a>