<?php 
$email["subjek"] = "Apa kabar";
$email["pengirim"] = "dianpelanicode.com";
$email["isi"] = "Apa kabar? sudah lama tidak jumpa";

echo"<pre>";
print r($email);
echo </pro>;