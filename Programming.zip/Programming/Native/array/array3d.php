<?php 
    $example = [
        [
            "nama" => "abdul",
            "peliharaan" =>
            [
                ["nama" => "marmot"],
                ["nama" => "kelinci"],
            ],
        ],
        [
            "nama" => "bebas",
            "peliharaan" =>
            [
                ["nama" => "burung"],
                ["nama" => "ayam"],
                ["nama" => "kucing"],
            ],
        ],
    ];
    
foreach ($example as $data) {
    echo "Nama Pemilik :".$data['nama']."<br>";
    echo "Daftar Hewan Peliharaan :";
    echo "<ul>";
    foreach ($data['peliharaan'] as $peliharaan) {
        echo "<li>".$peliharaan['nama']."</li>";
    }
    echo "</ul>";
}

?>