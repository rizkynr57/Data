<?php 
    $email["subjek"] = "Apa Kabar ?";
    $email["pengirim"] = "Dia Code";
    $email["isi"] = "Apa Kabar ? Sudah Lama tidak jumpa";

    echo "<pre>";
    print_r($email);
    echo "</pre>";

    echo $email["pengirim"];
?>