<?php 
    $arrNilai =  array ("Ani" => 80, "Otim" => 90, "Ana" => 75, "Budi" => 85);
    echo $arrNilai['Ani'];
    echo $arrNilai["Otim"];

    $arrNilai = array();
    $arrNilai['Ani'] = 80;
    $arrNilai['Asma'] = 95;
    $arrNilai['Sri'] = 77;

    echo $arrNilai['Asma'];
    echo $arrNilai['Ani'];


?>