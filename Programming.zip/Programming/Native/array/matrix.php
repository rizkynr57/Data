<?php 
    $matrix = [
//     0  1  2 
/*0*/ [2, 3, 4],
/*1*/ [7, 5, 0],
/*2*/ [4, 3, 8]
    ];
// index pertama adalah baris index kedua adalah kolom
// cara mengakses isinya
echo $matrix[1][2];
echo $matrix[2][1] . "<br>";

foreach ($matrix as $key => $val) 
{
    echo "baris $key : $val[0], $val[1], $val[2]<br>";
}
?>