<?php
    if (isset($_POST['save'])){
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        echo "<pre>";
        var_dump($nama);
        var_dump($kelas);
        echo "</pre>";
    }
?>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <fieldset>
        <legend>Data Siswa</legend>
        <table border = "1">
            <tr>
                <th>Nomor</th>
                <th>Nama</th>
                <th>Kelas</th>
            </tr>
            <?php
            $no = 1;
            for ($i = 0; $i < count($nama); $i++) { ?>
            <tr>
                <td><?php echo "<center>".$no++; ?></td>
                <td><?php echo "<center>".$nama[$i]; ?></td>
                <td><?php echo "<center>".$kelas[$i]; ?></td>
            </tr>
            <?php } ?>
        </table>
    </fieldset>
    <a href = "contoh1.php" name="Back">Back</a> 
</body>
</html>