<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Masukan Jumlah Data</td>
                    <td>:</td>
                    <td><input type="number" name="angka"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="input" value="Save"></td>
                       
                </tr>
            </table>
        </form>
    <?php
        if (isset($_POST['input'])) {
            $row = $_POST['angka'];
    ?>
    <fieldset>
        <table>
            <form action="contoh1.2.php" method="post">
            <?php
                for ($i = 1; $i <= $row; $i++){
            ?>
            <tr>
                <th colspan=2>Data Ke : <?php echo $i; ?></th>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name="nama[]"></td>
            </tr>
            <tr>
                <th colspan=2></th>
                <td>Kelas</td>
                <td>:</td>
                <td><input type="text" name="kelas[]"></td>
            </tr>
            <?php } ?>
            <tr>
                <th colspan=2></th>
                <td></td>
                <td></td>
                <td><input type="submit" name="save" value="Save"></td>
            </tr>
          </form>
         </table>
        </fielset>
    <?php } ?>
</body>
</html>