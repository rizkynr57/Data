<html>
  <head></head>
  <body>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama</td>
          <td>:</td>
          <td><input type= "text" name="nama" required> </td>
        </tr>
        <tr>
          <td>Jenis Kelamin</td>
          <td>:</td>
        <td>
          <input type="radio" name="jk" value="Laki - Laki">Laki - Laki
          <input type="radio" name="jk" value="Perempuan">Perempuan
       </td>
        </tr>
        <tr>
          <td>Agama</td>
          <td>:</td>
          <td><select name="agama" value="agama" required>
            <option value="">Pilih :</option>
            <option value="Islam">Islam</option>
            <option value="Kristen">Kristen</option>
            <option value="Hindu">Hindu</option>
            <option value="Buddha">Buddha</option>
          </select></td>
        </tr>
        <tr>
         <td>Golongan</td>
          <td>:</td>
          <td><select name="golongan" value="golongan" required>
            <option value="">Pilih :</option>
            <option name = "1" value="Golongan 1">Golongan 1</option>
            <option name = "2" value="Golongan 2">Golongan 2</option>
            <option name = "3" value="Golongan 3">Golongan 3</option>
            <option name = "4" value="Golongan 4">Golongan 4</option>
          </select></td>
        </tr>
        <tr>
          <td>Jumlah Jam</td>
          <td>:</td>
          <td><input type="number" name="jam" required></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="hitung" value="Menghitung"></td>
        </tr>
      </table>
    </form>
   </body>
  </html>

<?php 
    if (isset($_POST['hitung'])) {
      $nama = $_POST['nama'];
      $jk = $_POST['jk'];
      $agama = $_POST['agama'];
      $golongan = $_POST['golongan'];
      $jam = $_POST['jam'];
      
      echo "<b>Memilih : $golongan</b><br>";
     if ($golongan == 1 ) {
        $gaji = 1500000;
        $tunjangan = 150000;
      } else if($golongan == 2) {
        $gaji = 2000000;
        $tunjangan = 200000;
      } else if($golongan == 3) {
        $gaji = 2500000;
        $tunjangan = 250000;
      } else if($golongan == 4) {
        $gaji = 3000000;
        $tunjangan = 300000;
      }
       if ($gaji > 173) {
         $sisajam = $jam - 173;
         $lembur = 20000 * $sisajam;
       } else {
         $lembur = 0;
       }
      
      echo "Gaji Pokok : $gaji<br>";
      echo "Gaji Lembur : $lembur<br>";
      $pajakpokok = ($gaji * 5) / 100;
      echo "Pajak Gaji Pokok : $pajakpokok<br>";
      $pajaklembur = ($lembur * 5) / 100;
      echo "Pajak Gaji Lembur : $pajaklembur<br>";
      $totalpajak = $pajakpokok + $pajaklembur;
      echo "Total Pajak : $totalpajak";
      echo "Tunjangan Pengabdian : $tunjangan<br>";
      $totalgaji = ($gaji + $tunjangan) + $lembur;
      $total = $totalgaji - $totalpajak;
      echo "Gaji Diterima : $total";
    }
?>