<?php 
    $data = [
    ["dosen" => "Asep Dark Lord", 
    "submenu" => [
    ["nama" => "Aganim", 
    "matakuliah" => [
           ["matakuliah" => "Matematika"],
           ["matakuliah" => "Biologi"],
           ["matakuliah" => "IPA"]
           ],
                          
           "hobi" => [
           ["hobi" => "Memancing"],
           ["hobi" => "Menulis"],
           ["hobi" => "Membaca"]
           ]
           ],
          
     ["nama" => "Aisyah", "matakuliah" => [
           ["matakuliah" => "Inggris"],
           ["matakuliah" => "Indonesia"],
           ["matakuliah" => "Sunda"]
           ],
    
          "hobi" => [
           ["hobi" => "Menyanyi"],
           ["hobi" => "Menari"],
           ["hobi" => "Mendongeng"]
           ]
           ],
           
     ["nama" => "Roye", "matakuliah" => [
           ["matakuliah" => "Penjaskes"],
           ["matakuliah" => "Sejarah"],
           ["matakuliah" => "PKN"]
           ],
       
          "hobi" => [
           ["hobi" => "Berlari"],
           ["hobi" => "Bela Diri"],
           ["hobi" => "Argumen"]]],
          ]
          ],
          
          
         
     ["dosen" => "Dani Moon Breaker",
     "submenu" => [
          ["nama" => "Eris",
          "matakuliah" => [
          ["matakuliah" => "BK"],
          ["matakuliah" => "Seni Budaya"],
          ["matakuliah" => "Kimia"]
          ],
          
          "hobi" => [
              ["hobi" => "Ngebully"],
              ["hobi" => "Main Api"],
              ["hobi" => "Main Bola"]
              ]
              ],
              
          ["nama" => "Aris",
          "matakuliah" => [["matakuliah" => "BK"],
          ["matakuliah" => "Seni Budaya"],
          ["matakuliah" => "Kimia"]
          ],
          
          "hobi" => [
              ["hobi" => "Ngebully"],
              ["hobi" => "Main Api"],
              ["hobi" => "Main Bola"]
              ]
              ],
              
          ["nama" => "Erlan",
          "matakuliah" => [["matakuliah" => "BK"],
          ["matakuliah" => "Seni Budaya"],
          ["matakuliah" => "Kimia"]
          ],
          
          "hobi" => [
              ["hobi" => "Ngebully"],
              ["hobi" => "Main Api"],
              ["hobi" => "Main Bola"]
              ]
              ],
             ]
            ],
        ];
    $no = 1;
    foreach ($data as $key => $index) {
        echo "Nama Wali Dosen : ".$index['dosen']."<br>";
        echo "Daftar Mahasiswa : ";
        echo "<ul>";
        
        foreach ($index['submenu'] as $menu) {
            echo "<li> Data Ke-".$no++."</li>";
            echo "Daftar Mahasiswa : ".$menu['nama'];
            echo "<br>Daftar Mata Kuliah :";
            echo "<ol>";
            
           foreach ($menu['matakuliah'] as $matkul) {
           echo "<li>".$matkul['matakuliah']."</li>";
            }
            echo "</ol>";
        }
            echo " Daftar Hobi :";
            echo "<ol>";
            foreach ($menu['hobi'] as $hobi) {
                echo "<li>".$hobi['hobi']."</li>";
           }  
        echo "</ol>";
        echo "</ul>";
    }

?>