<html>
  <head></head>
  <body>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama Mahasiswa</td>
          <td>:</td>
          <td><input type="text" name="nama" required></td>
        </tr>
        <tr>
          <td>NIM</td>
          <td>:</td>
          <td><input type="number" name="nim" required></td>
        </tr>
        <tr>
          <td>Nilai</td>
          <td>:</td>
          <td><input type="number" name="nilai" required></td>
        </tr>
        <tr>
          <td>Nama Dosen</td>
          <td>:</td>
          <td><input type="text" name="dosen" required></td>
        </tr>
        <tr>
          <td>
             <select name="matkul" required>
               <option value="Bahasa Indonesia">Bahasa Indonesia</option>
               <option value="IPA">IPA</option>
               <option value="Matematika">Matematika</option>
             </select>
          </td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="save" value="Save"></td>
        </tr>
      </table>
    </form>
  </body>
</html>
<?php
if (isset($_POST['save'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $nilai = $_POST['nilai'];
    $dosen = $_POST['dosen'];
    $matkul = $_POST['matkul'];
    
    class mahasiswa
    {
        public $nama;
        public $nim;
        public $dosen;
        
        public function __construct($nama,$nim,$dosen)
        {
            $this->nama = $nama;
            $this->nim = $nim;
            $this->dosen = $dosen;
        }
    }
    class matakuliah extends mahasiswa 
    {
        public $matkul;
        public $nilai;
        
        public function __construct($matkul,$nilai)
        {
            $this->matkul = $matkul;
            $this->nilai = $nilai;
        }
        public function nilai()
        {
            if ($this->nilai >= 85) {
                $ket = "Grade A (Lulus)";
            } else if ($this->nilai >= 75) {
                $ket = "Grade B (Lulu)";
            } else if ($this->nilai >= 65) {
                $ket = "Grade C (Perbaikan)";
            } else {
                $ket = "Grade D (Tidak Lulus)";
            }
            return $ket;
        }
    }
    
$kuliah = new matakuliah($nama,$nim,$nilai,$dosen,$matkul);
$kuliah->nama = $nama;
$kuliah->nim = $nim;
$kuliah->nilai = $nilai;
$kuliah->dosen = $dosen;
$kuliah->matkul = $matkul;
echo "Nama Mahasiswa : ".$kuliah->nama."<br>";
echo "NIM : ".$kuliah->nim."<br>";
echo "Nilai : ".$kuliah->nilai."<br>";
echo "Nama Dosen : ".$kuliah->dosen."<br>";
echo "Mata Kuliah : ".$kuliah->matkul."<br>";
echo "Status : ".$kuliah->nilai();
}
?>