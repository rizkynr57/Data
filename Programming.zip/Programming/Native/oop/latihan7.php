<html>
  <head></head>
  <body>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama Mahasiswa</td>
          <td>:</td>
          <td><input type="text" name="nama"></td>
        </tr>
        <tr>
          <td>NIM</td>
          <td>:</td>
          <td><input type="number" name="nim"></td>
        </tr>
        <tr>
          <td>Nilai</td>
          <td>:</td>
      <td><input type="number" name="nilai" min="0" max="100"></td>
        </tr>
        <tr>
          <td>Nama Dosen</td>
          <td>:</td>
          <td><input type="name" name="dosen"></td>
        </tr>
        <tr>
          <td>Mata Kuliah</td>
          <td>:</td>
          <td>
            <select name="matkul" required>
              <option value="">Pilih</option>
              <option value="Bahasa Indonesia">Bahasa Indonesia</option>
              <option value="Bahasa Inggris">Bahasa Inggris</option>
              <option value="Matematika">Matematika</option>
            </select>
          </td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="save" value="Save"></td>
        </tr>
      </table>
    </form>
  </body>
</html>

<?php
if (isset($_POST['save'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $matkul = $_POST['matkul'];
    $dosen = $_POST['dosen'];
    $nilai = $_POST['nilai'];

    class mahasiswa
    {
        public $nama;
        public $nim;
        public $matkul;
        
        public function __construct($nama, $nim, $matkul) {
            $this->nama = $nama;
            $this->nim = $nim;
            $this->matkul = $matkul;
        }
    }
    class universitas extends mahasiswa
    {
        public $dosen;
        public $nilai;
        
        public function __construct($dosen, $nilai) {
            $this->dosen = $dosen;
            $this->nilai = $nilai;
        }
        public function nilaikuliah()
        {
            if ($this->nilai >= 85) {
                $ket = "Grade A (Lulus)";
            } else if($this->nilai >= 75) {
                $ket = "Grade B (Lulus)";
            } else if($this->nilai >= 65) {
                $ket = "Grade C (Perbaikan)";
            } else {
                $ket = "Grade D (Tidak Lulud)";
            }
            return $ket;
        }
    }
    
    $data = new universitas($nama, $nim, $matkul, $dosen, $nilai);
    $data->nama = $nama;
    $data->nim = $nim;
    $data->matkul = $matkul;
    $data->dosen = $dosen;
    $data->nilai = $nilai;
    
    echo "Nama : ".$data->nama."<br>";
    echo "NIM : ".$data->nim."<br>";
    echo "Mata Kuliah : ".$data->matkul."<br>";
    echo "Dosen : ".$data->dosen."<br>";
    echo "Nilai : ".$data->nilai."<br>";
    echo "Status : ".$data->nilaikuliah();
    
}
?>