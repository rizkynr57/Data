<?php
class komputer
{
    protected $jenisProcessor = "Intel Core I7";

    protected function tampilkanjenisprocessor()
    {
        return $this->jenisProcessor;
    }
}

class laptop extends komputer
{
    public function getProcessor()
    {
        return $this->tampilkanjenisprocessor();
    }
}

$laptop = new laptop();
echo $laptop->getProcessor();
