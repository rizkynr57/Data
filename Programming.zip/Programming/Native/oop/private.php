<?php
class komputer
{
    private $jenisProcessor = "Intel Core I7";

    public function tampilkanjenisprocessor()
    {
        return $this->jenisProcessor;
    }
}

class laptop extends komputer
{
    public function getProcessor()
    {
        return $this->jenisProcessor;
    }
}

$komputer = new komputer();
$laptop = new laptop();

echo $komputer->tampilkanjenisprocessor() . "<Br>";
echo $laptop->getProcessor();
