<html>
    <head></head>
    <body>
        <form action="" method="POST">
            <table>
                <tr>
                    <td>Nama Barang</td>
                    <td>:</td>
                    <td><input type="text" name="barang"></td>
                </tr>
                <tr>
                    <td>Harga</td>
                    <td>:</td>
                    <td><input type="text" name="harga"></td>
                </tr>
                <tr>
                    <td>Jumlah Pesanan</td>
                    <td>:</td>
                    <td><input type="number" name="jumlah"></td>
                </tr>
                <tr>
                    <td>Sistem Pembayaran</td>
                    <td>:</td>
                    <td><select name="metode">
                        <option value="">Pilih Metode</option>
                        <option value="Cash">Cash</option>
                        <option value="M-bangking">M-Banking</option>
                        <option value="Gopay">Gopay</option>
                        <option value="Pickup">Pickup</option>

                    </select></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="save" value="Totalkan" </td>
                </tr>
            </table>
        </form>
    </body>
</html>
<?php
if (isset($_POST['save'])) {
    $barang = $_POST['barang'];
    $harga = $_POST['harga'];
    $jumlah = $_POST['jumlah'];
    $metode = $_POST['metode'];

    class aplikasi
    {
        public $barang;
        public $harga;
        public $jumlah;

        public function __construct($barang, $harga, $jumlah)
        {
            $this->barang = $barang;
            $this->harga = $harga;
            $this->jumlah = $jumlah;
        }
        public function total()
        {
          return $this->harga * $this->jumlah;
        }
        protected function diskon()
        {
          if ($this->total() > 250000) {
            $diskon = $this->total() * 0.15;
          } else if($this->total() > 150000) {
            $diskon = $this->total() * 0.1;
          } else {
            $diskon = 0;
          }
          return $diskon;
        }
    }
    
    class commerce extends aplikasi
    {
      public $metode;
      
      public function __construct($metode)
      {
        $this->metode = $metode;
      }
      public function totally()
      {
        return $this->total();
      }
      public function diskontambah()
      {
        if ($this->metode == "M-Banking") {
          $bonus = $this->totally() * 0.025;
        } else if ($this->metode == "Pickup") {
          $bonus = $this->totally() * 0.015;
        } else {
          $bonus = 0;
        }
        return $bonus;
      }
      public function getDiscount()
      {
        return $this->diskon() + $this->diskontambah();
      }
      public function cashback()
      {
        if ($this->metode == "Gopay") {
          $cashback = $this->totally() * 0.1;
        } else if ($this->metode == "Cash") {
          $cashback = 0;
        } else {
          $cashback = 0;
        }
        return $cashback;
      }
      public function keseluruhan()
      {
        return $this->totally() - $this->getDiscount() - $this->cashback();
      }
    }
    $data = new commerce($barang, $harga, $jumlah);
    $data->barang = $barang;
    $data->harga = $harga;
    $data->jumlah = $jumlah;
    $data->metode = $metode;
    
    echo "Nama Barang : ".$data->barang."<br>";
    echo "Harga Barang : ".$data->harga."<br>";
    echo "Jumlah Barang : ".$data->jumlah."<br>";
    echo "Total Harga Pokok : ".$data->totally()."<br>";
    echo "Diskon : ".$data->getDiscount()."<br>";
    echo "Cashback : ".$data->cashback()."<br>";
    echo "Total Yang Harus Dibayar : ".$data->keseluruhan();
}
?>