<html>
    <head></head>
    <body>
        <h2>Program Penggajian Web Developer</h2>
    <form action="" method="POST">
      <table>
        <tr>
          <td>Nama</td>
          <td>:</td>
          <td><input type="text" name="nama"></td>
        </tr>
        <tr>
          <td>Jenis Kelamin</td>
          <td>:</td>
          <td><input type="radio" name="jk" value="Laki - Laki">Laki - Laki
            <input type="radio" name="jk" value="Perempuan">Perempuan
    </td>
        </tr>
        <tr>
          <td>Agama</td>
          <td>:</td>
          <td><select name="agama" required>
          <option value="">Pilih</option>
          <option value="Islam">Islam</option>
          <option value="Kristen">Kristen</option>
          <option value="Buddha">Buddha</option>
          <option value="Hindu">Hindu</option>
      </select></td>
        </tr>
        <tr>
          <td>Profesi</td>
          <td>:</td>
          <td><input type="radio" name="profesi" value="Front End Developer">Front End Developer<br>
              <input type="radio" name="profesi" value="Back End Developer">Back End Developer<Br>
              <input type="radio" name="profesi" value="Full Stack Developer">Full Stack Developer
        </td>
        </tr>
        <tr>
          <td>Pilih Golongan</td>
          <td>:</td>
          <td>
            <select name="golongan" required>
              <option value="">Pilih</option>
              <option value="A">Golongan A</option>
              <option value="B">Golongan B</option>
              <option value="C">Golongan C</option>
            </select>
          </td>
        </tr>
        <tr>
            <td>Total Jam Kerja</td>
            <td>:</td>
            <td><input type="number" name="jam" required></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td><input type="submit" name="save" value="Penggajian"></td>
        </tr>
      </table>
    </form>
  </body>
</html>
<?php
if (isset($_POST['save'])) {
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $agama = $_POST['agama'];
    $profesi = $_POST['profesi'];
    $golongan = $_POST['golongan'];
    $jam = $_POST['jam'];

    class biodata
{
    public $nama;
    public $jk;
    public $agama;
    public $profesi;
    
    public function __construct($nama, $jk, $agama, $profesi)
    {
        $this->nama = $nama;
        $this->jk = $jk;
        $this->agama = $agama;
        $this->profesi = $profesi;
    }
}

class penggajian extends biodata 
{
    public $golongan;
    public $jam;
    
    public function __construct($golongan, $jam)
      {
        $this->golongan = $golongan;
        $this->jam = $jam;
      }
    public function gajipokok()
    {
        if ($this->golongan == "A") {
            $gaji = 7500000;
        } else if ($this->golongan == "B") {
            $gaji = 8000000;
        } else if ($this->golongan == "C") {
            $gaji = 8500000;
        } else if ($this->golongan == "D") {
        	$gaji = 9000000;
        }
        return $gaji;
    }
    public function tunjangan()
    {
    	 if ($this->golongan == "A") {
            $tunjangan = 500000;
        } else if ($this->golongan == "B") {
            $tunjangan = 550000;
        } else if ($this->golongan == "C") {
            $tunjangan = 600000;
        } else if ($this->golongan == "D") {
        	$tunjangan = 650000;
        }
        return $tunjangan;
    }
    public function gajilembur()
    {
        if ($this->jam > 173) {
            $sisajam = $this->jam - 173;
            $lembur = $sisajam * 50000;
        } else {
            $lembur = 0;
        }
        return $lembur;
    }
    public function pajaklembur()
    {
        return $this->gajilembur() * 0.05;
    }
    public function pajakpokok()
    {
        return $this->gajipokok() * 0.05;
    }
    public function totalpajak()
    {
        return $this->pajaklembur() + $this->pajakpokok();
    }
    public function totalgaji()
    {
        return $this->gajipokok() + $this->gajilembur();
    }
    public function keseluruhan()
    {
        return ($this->totalgaji() + $this->tunjangan()) - $this->totalpajak();
    }
}
    $gajian = new penggajian($nama, $jk, $agama, $profesi, $golongan, $jam);
    $gajian->nama = $nama;
    $gajian->jk = $jk;
    $gajian->agama = $agama;
    $gajian->profesi = $profesi;
    $gajian->golongan = $golongan;
    $gajian->jam = $jam;
    
    echo "Nama : ".$gajian->nama."<br>";
    echo "Jenis Kelamin : ".$gajian->jk."<br>";
    echo "Agama : ".$gajian->agama."<br>";
    echo "Profesi : ".$gajian->profesi."<br>";
    echo "Golongan : ".$gajian->golongan."<br>";
    echo "Total Jam : ".$gajian->jam."<br>";
    echo "Gaji Lembur : ".$gajian->gajilembur()."<br>";
    echo "Gaji Pokok : ".$gajian->gajipokok()."<br>";
    echo "Tunjangan Pengabdian : ".$gajian->tunjangan()."<br>";
    echo "Total Pajak : ".$gajian->totalpajak()."<br>";
    echo "Gaji Diterima : ".$gajian->keseluruhan();
}
?>
