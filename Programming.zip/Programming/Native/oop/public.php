<?php
class laptop
{
    public $pemilik;

    public function hidupkan_laptop()
    {
        return "Hidupkan Laptop";
    }
}
$laptopAnto = new laptop();
$laptopAnto->pemilik = "Anto";

echo $laptopAnto->pemilik . " ";
echo $laptopAnto->hidupkan_laptop();
