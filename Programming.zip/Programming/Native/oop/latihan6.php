<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
        <form action="" method="POST">
            <table>
            <tr>
                <td>Nama Kucing</td>
                <td> : </td>
                <td><input type="text" name="kucing"></td>
            </tr>
            <tr>
                <td>Warna Kucing</td>
                <td> : </td>
                <td><input type="text" name="warna"></td>
            </tr>
            <tr>
                <td>Jumlah Kaki Kucing</td>
                <td> : </td>
                <td><input type="number" name="jumlahkaki" min="0" max="5"></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="submit" name="save" value="Save">
            </tr>
            </table>
        </form>
</body>
</html>

<?php
if (isset($_POST['save'])) {
    $kucing = $_POST['kucing'];
    $warna = $_POST['warna'];
    $jumlahKaki = $_POST['jumlahkaki'];

    class kucing
    {
        public $kucing;
        public $warna;
        public $jumlahkaki;
        
        public function __construct($kucing, $warna, $jumlahkaki)
        {
            $this->kucing = $kucing;
            $this->warna = $warna;
            $this->jumlahkaki = $jumlahkaki;
        }
        public function kakikucing()
        {
            if($this->jumlahkaki > 4) {
                $ket = "Siluman";
            } else if($this->jumlahkaki == 4) {
                $ket = "Normal";
            } else if($this->jumlahkaki < 4) {
                $ket = "Cingked";
            }
            return $ket;
        }
    }
    $data = new kucing($kucing, $warna, $jumlahkaki);
    $data->kucing = $kucing;
    $data->warna = $warna;
    $data->jumlahkaki = $jumlahkaki;
    
    echo "Nama Kucing : ".$data->kucing."<br>";
    echo "Warna Kucing : ".$data->warna."<br>";
    echo "Jumlah Kaki : ".$data->jumlahkaki."<br>";
    echo "Kondisi : ".$data->kakikucing();
}
?>