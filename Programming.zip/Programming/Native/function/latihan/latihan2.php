<html>
    <head>
        <body>
            <h2>Menghitung Bangun Lingkaran</h2>
            <form action ="" method ="post">
            <table>
            <tr>
            <td><b>Masukan Jari Jari</b></td>
            <td>:</td>
            <td><input type = "number" name="jari"></td>
</tr>   
<tr>
    <td></td>
    <td></td>
            <td><input type = "submit" name="hitung" value="Menghitung"></td>
            </tr>
            </table>
        </body>
    </head>
</html>
<?php 
    if (isset($_POST['hitung'])) {
        $jari = $_POST['jari'];
    function luasLingkaran($jari, $phi = 3.14)
    {
        $luas = 2 * ($jari * $phi);
        return $luas;
    }
    function kelilingLingkaran($jari, $phi = 3.14)
    {
        $keliling = ($jari * 2) * ($phi * 2);
        return $keliling;
    }
    echo "Jari Jari : $jari<br>";
    echo "Luas Lingkaran : ".luasLingkaran($jari)."<br>";
    echo "Keliling Lingkaran : ".kelilingLingkaran($jari);
}
?>