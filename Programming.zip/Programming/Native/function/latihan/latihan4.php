<html>
    <head></head>
    <body>
        <form action="" method="post">
            <table>
                <tr>
                    <td>Masukan Bilangan</td>
                    <td>:</td>
                    <td><input type="number" name="bil1" min="0" required></td>
                </tr>
                <tr>
                    <td>Masukan Pangkat</td>
                    <td>:</td>
                    <td><input type="number" name="bil2" min="0" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" name="hitung" value="Menghitung"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
<?php 
    if (isset($_POST['hitung'])) {
        $bil1 = $_POST['bil1'];
        $bil2 = $_POST['bil2'];

    function bilangan($bil1,$bil2) {
        if ($bil2 > 1) {
         return $bil1 * bilangan($bil1, $bil2 - 1);
        } else {
                return $bil1;
            }
        }
    function perpangkatan($bil1,$bil2) {
        for ($i = 1; $i <= $bil2; $i++) {
            echo $bil1;
            if ($i < $bil2) {
                echo " x ";
            }
        }
    } 
    echo "Perpangkatan ";
    echo perpangkatan($bil1,$bil2);
    echo " = ".bilangan($bil1,$bil2);
}
?>